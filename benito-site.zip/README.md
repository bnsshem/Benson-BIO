# Benito - biography website

A one-page static site. No build step: open `index.html` in a browser.

## Files
- `index.html` - the whole site (HTML and CSS)
- `img/` - photos used on the page

## Host it free with GitHub Pages
1. Push this folder to a GitHub repository.
2. Repository Settings > Pages.
3. Source: Deploy from a branch. Branch: `main`, folder: `/ (root)`. Save.
4. After a minute the site is live at `https://<your-username>.github.io/<repo-name>/`.
